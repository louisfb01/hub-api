function get(periodStart: string, periodCount: number) {
    return { periodStart, periodCount }
}

export default {
    get
}