export default {
    AllSitesName: 'all',
    webSocketWaitTime: 300_000 // 180 seconds or 3 minutes.
}