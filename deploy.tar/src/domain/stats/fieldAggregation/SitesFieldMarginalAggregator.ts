import DiscreteVariableMarginalResponse from "../../../models/Response/DiscreteVariableMarginalReponse";
import FieldResponse from "../../../models/Response/FieldResponse";

function calculate(specificFieldResponses: FieldResponse[]): DiscreteVariableMarginalResponse {
    throw new Error('Not implements');
}

export default {
    calculate
}