export default interface DiscreteVariableMarginalResponse {

}