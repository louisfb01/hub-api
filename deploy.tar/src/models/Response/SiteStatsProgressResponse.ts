export default interface SiteStatsProgressResponse {
    job: string;
    ready: boolean;
    error?: string;
}