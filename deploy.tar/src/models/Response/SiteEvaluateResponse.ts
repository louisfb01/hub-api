export default interface SiteEvaluateResponse {
    metrics: any;
    job: string;
    error?: string;
}