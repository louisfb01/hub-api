export default interface HubRequestResponse {
    siteCode: string;
    job: string;
    error?: string;
}