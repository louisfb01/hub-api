export default interface SiteTrainResponse {
    metrics: any;
    job: string;
    weights?: any;
    error?: string;
}