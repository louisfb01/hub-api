export default interface HubEvaluateResponse {
    metrics: any;
    siteCode: string;
    error?: string;
}