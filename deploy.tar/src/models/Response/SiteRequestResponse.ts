export default interface SiteRequestResponse {
    job: string;
    error?: string;
}