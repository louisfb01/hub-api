export default interface ContinuousMeanResponse {
    mean: number;
    populationSize: number;
}