export default interface DiscreteVariableCountReponse {
    label: string;
    value: number;
}