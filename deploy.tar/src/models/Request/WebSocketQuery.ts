export default interface WebSocketQuery {
    body: any,
    sites: string[],
    waitTime: number
}