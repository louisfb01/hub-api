export default interface BreakdownResource {
    type: string;
    field: string;
    fieldType: string;
}