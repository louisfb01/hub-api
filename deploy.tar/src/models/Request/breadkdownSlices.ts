export default interface BreakdownSlices {
    step: number;
    min: string;
    max: string;
}