export default interface Field {
    path: string;
    label: string;
    type: string;
}