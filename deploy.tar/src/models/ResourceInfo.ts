export default interface ResourceInfo {
    type: string;
    attribute: string;
    begin_date: Date;
    end_date: Date;
    datatype: string;
}